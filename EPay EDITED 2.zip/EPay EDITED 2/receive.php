<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.82.0">
    <title>EPay</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      <style>
          .border {
            /*border: 5px solid black;*/
            /*border-collapse: collapse;*/
            border-spacing: 5px;
          }

          .text_align {
             padding: 15px;
            text-align: center;

          }
          .center {
            margin-left: auto;
            margin-right: auto;
          }

          .bg-dark {
            background-color:#212529!important
          }

          .text-white {
            color:#fff!important
          }

          td {
            padding-right: 15px;
            padding-left: 15px;

          }
          pad-left {
            padding-left: 15px;
          }
      </style>
    </style>

    
    <!-- Custom styles for this template -->
    <link href="css1/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    
<div class="container center">
  <main>
    <div class="py-5 text-center">
      
      <h2>Receive Payment</h2>
     
    </div>

    <div class="row g-5">
      


      <div class="col-md-7 col-lg-6 center">
        
        <form class="needs-validation" novalidate>
          <div class="row g-3">
            

            
        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">User ID</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>
        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Client ID</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Transaction History</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Payment Type</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Mode of Payment</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Amount</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Currency</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
          <span class="input-group-text" id="basic-addon1">Status</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>
      
 

          <hr class="my-4">

          <button class="w-100 btn btn-outline-primary btn-lg" type="submit">Submit</button>
        </form>
      </div>
    </div>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    
  </footer>
</div>


    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>

      <script src="css1/form-validation.js"></script>
  </body>
</html>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.82.0">
    <title>EPay</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      <style>
          .border {
            /*border: 5px solid black;*/
            /*border-collapse: collapse;*/
            border-spacing: 5px;
          }

          .text_align {
             padding: 15px;
            text-align: center;

          }
          .center {
            margin-left: auto;
            margin-right: auto;
          }

          .bg-dark {
            background-color:#212529!important
          }

          .text-white {
            color:#fff!important
          }

          td {
            padding-right: 15px;
            padding-left: 15px;

          }
          pad-left {
            padding-left: 15px;
          }
      </style>
    </style>

    
    <!-- Custom styles for this template -->
    <link href="css1/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    
<div class="container center">
  <main>
    <div class="py-5 text-center">
     
      <h2>Make Payment</h2>
     
    </div>

    <div class="row g-5">
      


      <h4 class="mb-3" style="text-align: center;">Payment Method</h4>
     

          <div class="row gy-3 col-lg-8 center">
            <div class="col-md-6">
              
              <input type="text" class="form-control" id="cc-name" placeholder="Name on Card" required>
              <small class="text-muted">Full name as displayed on card</small>
              <div class="invalid-feedback">
                Name on card is required
              </div>
            </div>

            <div class="col-md-6">
              
              <input type="text" class="form-control" id="cc-number" placeholder="Credit Card Number" required>
              <div class="invalid-feedback">
                Credit card number is required
              </div>
            </div>

            <div class="col-md-6">
              
              <input type="text" class="form-control" id="cc-expiration" placeholder="Expiration" required>
              <div class="invalid-feedback">
                Expiration date required
              </div>
            </div>

            <div class="col-md-6">
              
              <input type="text" class="form-control" id="cc-cvv" placeholder="CVV" required>
              <div class="invalid-feedback">
                Security code required
              </div>
            </div>
            
            <hr class="my-4">

          </div>

          


      <div class="col-md-7 col-lg-6 center">
        <h4 class="mb-3" style="text-align: center;">Billing Information</h4>
        <form class="needs-validation" novalidate>
          <div class="row g-3">
            <div class="col-sm-6">
              <!----
              <label for="firstName" class="form-label">First name</label>
              ----->
              <input type="text" class="form-control" id="firstName" placeholder="Company Name*" value="" required>
              <div class="invalid-feedback">
                Valid company name is required.
              </div>
            </div>

            <div class="col-sm-6">
              
              <input type="text" class="form-control" id="lastName" placeholder="Full Name*" value="" required>
              <div class="invalid-feedback">
                Valid full name is required.
              </div>
            </div>

            

            <div class="col-12">
              
              <input type="text" class="form-control" id="address" placeholder="Address Line 1*" required>
              <div class="invalid-feedback">
                Please enter a valid address address.
              </div>
            </div>

            <div class="col-12">
              
              <input type="text" class="form-control" id="address2" placeholder="Address Line 2">
            </div>


            <div class="col-md-6">
              
              <input type="text" class="form-control" id="address" placeholder="City" required>
              <div class="invalid-feedback">
                Please enter your city.
              </div>
            </div>

            <div class="col-md-6">
              
              <input type="text" class="form-control" id="address" placeholder="Town" required>
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>


            <div class="col-md-6">
              
              <input type="text" class="form-control" id="address" placeholder="Postal Code" required>
              <div class="invalid-feedback">
                Please enter your postal code.
              </div>
            </div>

            <div class="col-md-6">
              
              <input type="text" class="form-control" id="address" placeholder="Phone Number" required>
              <div class="invalid-feedback">
                Please enter your phone number.
              </div>
            </div>

            <div class="col-12">
              
              <input type="email" class="form-control" id="email" placeholder="Email Address">
              
            </div>
           
         

          

          <hr class="my-4">

          <button class="w-100 btn btn-outline-primary btn-lg" type="submit">Make Payment</button>
        </form>
      </div>
    </div>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    
  </footer>
</div>


    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>

      <script src="css1/form-validation.js"></script>
  </body>
</html>
